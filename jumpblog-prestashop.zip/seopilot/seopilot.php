<?php
/**
 * Jump Blog - blog SEO automatico collegato alla piattaforma Jump Blog (jumpblog.com.br).
 *
 * - Blog multilingua con URL propri (/blog e /blog?post=slug)
 * - API protetta da chiave per ricevere articoli dalla piattaforma
 * - Jump SEO: ottimizzazione dei testi SEO dei prodotti
 * - SEO: meta title/description, canonical, hreflang, JSON-LD, sitemap
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/classes/SeoPilotPost.php';
require_once __DIR__ . '/classes/SeoPilotContent.php';
require_once __DIR__ . '/classes/SeoPilotImageFetcher.php';

class SeoPilot extends Module
{
    const CFG_API_KEY = 'SEOPILOT_API_KEY';
    const CFG_ROUTE = 'SEOPILOT_ROUTE';
    const CFG_PER_PAGE = 'SEOPILOT_PER_PAGE';
    const CFG_BLOG_TITLE = 'SEOPILOT_BLOG_TITLE';
    const CFG_BLOG_DESC = 'SEOPILOT_BLOG_DESC';
    const CFG_PRIORITY = 'SEOPILOT_ROUTE_PRIORITY';
    const CFG_PANEL_URL = 'SEOPILOT_PANEL_URL';
    const CFG_CONNECTED = 'SEOPILOT_CONNECTED';

    public function __construct()
    {
        $this->name = 'seopilot';
        $this->tab = 'content_management';
        $this->version = '1.4.1';
        $this->author = 'Jump Blog';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = ['min' => '1.7.7.0', 'max' => _PS_VERSION_];
        parent::__construct();
        $this->displayName = $this->l('Jump Blog - Blog SEO automatico');
        $this->description = $this->l('Blog multilingua con articoli SEO scritti e pubblicati in automatico da Jump Blog.');
    }

    public function install()
    {
        return parent::install()
            && $this->installDb()
            && $this->registerHook('moduleRoutes')
            && $this->registerHook('displayHeader')
            && $this->registerHook('gSitemapAppendUrls')
            && Configuration::updateValue(self::CFG_API_KEY, bin2hex(random_bytes(24)))
            && Configuration::updateValue(self::CFG_ROUTE, 'blog')
            && Configuration::updateValue(self::CFG_PER_PAGE, 12)
            && $this->installMenu()
            && (is_dir(_PS_IMG_DIR_ . 'seopilot') || mkdir(_PS_IMG_DIR_ . 'seopilot', 0755, true));
    }

    /** Voce "Jump Blog" nel menu di sinistra (sezione Migliora). */
    public function installMenu()
    {
        if ((int) Tab::getIdFromClassName('AdminSeoPilot')) {
            return true;
        }
        $tab = new Tab();
        $tab->class_name = 'AdminSeoPilot';
        $tab->module = $this->name;
        $tab->id_parent = (int) Tab::getIdFromClassName('IMPROVE');
        $tab->icon = 'trending_up';
        $tab->active = 1;
        foreach (Language::getLanguages(false) as $l) {
            $tab->name[$l['id_lang']] = 'Jump Blog';
        }

        return (bool) $tab->add();
    }

    public function uninstall()
    {
        $id = (int) Tab::getIdFromClassName('AdminSeoPilot');
        if ($id) {
            (new Tab($id))->delete();
        }
        // Le tabelle NON vengono cancellate: gli articoli sono contenuti indicizzati.
        foreach ([self::CFG_API_KEY, self::CFG_ROUTE, self::CFG_PER_PAGE, self::CFG_BLOG_TITLE, self::CFG_BLOG_DESC, self::CFG_PRIORITY, self::CFG_PANEL_URL, self::CFG_CONNECTED] as $k) {
            Configuration::deleteByName($k);
        }

        return parent::uninstall();
    }

    protected function installDb()
    {
        $p = _DB_PREFIX_;
        $engine = _MYSQL_ENGINE_;
        $sql = [
            "CREATE TABLE IF NOT EXISTS `{$p}seopilot_post` (
                `id_seopilot_post` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_shop` INT UNSIGNED NOT NULL DEFAULT 1,
                `external_id` VARCHAR(64) NULL,
                `source` VARCHAR(16) NOT NULL DEFAULT 'platform',
                `image` VARCHAR(255) NULL,
                `active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
                `date_publish` DATETIME NOT NULL,
                `date_add` DATETIME NOT NULL,
                `date_upd` DATETIME NOT NULL,
                PRIMARY KEY (`id_seopilot_post`),
                UNIQUE KEY `external` (`id_shop`, `external_id`),
                KEY `publish` (`id_shop`, `active`, `date_publish`)
            ) ENGINE={$engine} DEFAULT CHARSET=utf8mb4",
            "CREATE TABLE IF NOT EXISTS `{$p}seopilot_post_lang` (
                `id_seopilot_post` INT UNSIGNED NOT NULL,
                `id_lang` INT UNSIGNED NOT NULL,
                `title` VARCHAR(255) NOT NULL,
                `slug` VARCHAR(190) NOT NULL,
                `excerpt` TEXT NULL,
                `content` LONGTEXT NULL,
                `meta_title` VARCHAR(255) NULL,
                `meta_description` VARCHAR(512) NULL,
                `keyword` VARCHAR(255) NULL,
                `image_alt` VARCHAR(255) NULL,
                PRIMARY KEY (`id_seopilot_post`, `id_lang`),
                KEY `slug` (`id_lang`, `slug`)
            ) ENGINE={$engine} DEFAULT CHARSET=utf8mb4",
        ];
        foreach ($sql as $q) {
            if (!Db::getInstance()->execute($q)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Se attivo, le rotte del blog Jump Blog vengono valutate prima di quelle degli altri moduli
     * (es. il blog del tema che usa anch'esso /blog). Gli indirizzi diversi (es. /blog/post/6/...) restano all'altro modulo.
     */
    public function applyRoutePriority($first)
    {
        $idHook = (int) Hook::getIdByName('moduleRoutes');
        if (!$idHook) {
            return;
        }
        if ($first) {
            $this->updatePosition($idHook, false, 1);
        } else {
            $max = (int) Db::getInstance()->getValue('SELECT MAX(position) FROM `' . _DB_PREFIX_ . 'hook_module` WHERE id_hook = ' . $idHook . ' AND id_shop = ' . (int) $this->context->shop->id);
            $this->updatePosition($idHook, true, $max);
        }
        Cache::clean('hook_module_list');
        Tools::clearAllCache();
    }

    public static function route()
    {
        $r = trim((string) Configuration::get(self::CFG_ROUTE), '/');

        return $r !== '' ? $r : 'blog';
    }

    /**
     * Rotte: /{route} (elenco, e articolo con ?post=slug) e /{route}/{slug}.
     */
    public function hookModuleRoutes()
    {
        $route = self::route();

        return [
            'module-seopilot-blogpost' => [
                'controller' => 'blog',
                'rule' => $route . '/{post}',
                'keywords' => [
                    'post' => ['regexp' => '[_a-zA-Z0-9\pL\pS-]+', 'param' => 'post'],
                ],
                'params' => ['fc' => 'module', 'module' => 'seopilot'],
            ],
            'module-seopilot-blog' => [
                'controller' => 'blog',
                'rule' => $route,
                'keywords' => [],
                'params' => ['fc' => 'module', 'module' => 'seopilot'],
            ],
        ];
    }

    public function hookDisplayHeader()
    {
        $c = $this->context->controller;
        if ($c instanceof ModuleFrontController && isset($c->module) && $c->module->name === $this->name) {
            $this->context->controller->registerStylesheet('seopilot', 'modules/' . $this->name . '/views/css/seopilot.css', ['media' => 'all', 'priority' => 150]);
        }

        return '';
    }

    /**
     * URL pubblico di un articolo. Formato: /blog?post=slug
     */
    public function getPostUrl($slug, $idLang = null)
    {
        $idLang = $idLang ?: (int) $this->context->language->id;

        return $this->context->link->getModuleLink($this->name, 'blog', ['post' => $slug], null, $idLang);
    }

    public function getBlogUrl($idLang = null, $page = 1)
    {
        $params = $page > 1 ? ['page' => (int) $page] : [];

        return $this->context->link->getModuleLink($this->name, 'blog', $params, null, $idLang ?: (int) $this->context->language->id);
    }

    public static function imageUrl($image)
    {
        if (!$image) {
            return '';
        }
        if (preg_match('#^https?://#', $image)) {
            return $image;
        }

        return Context::getContext()->link->getBaseLink() . 'img/seopilot/' . rawurlencode($image);
    }

    /** Hook del modulo gsitemap: aggiunge tutti gli articoli alla sitemap. */
    public function hookGSitemapAppendUrls($params)
    {
        $idLang = (int) (isset($params['lang']['id_lang']) ? $params['lang']['id_lang'] : $this->context->language->id);
        $urls = [];
        foreach (SeoPilotPost::getPublished($idLang, (int) $this->context->shop->id, 0, 100000) as $row) {
            $urls[] = [
                'page' => 'seopilot',
                'link' => $this->getPostUrl($row['slug'], $idLang),
                'image' => $row['image'] ? ['link' => self::imageUrl($row['image']), 'title_img' => $row['title'], 'caption' => $row['title']] : false,
            ];
        }
        $urls[] = ['page' => 'seopilot', 'link' => $this->getBlogUrl($idLang), 'image' => false];

        return $urls;
    }

    /* ------------------------------------------------------------------ */
    /* Configurazione                                                      */
    /* ------------------------------------------------------------------ */

    public function getContent()
    {
        $this->installMenu(); // crea la voce di menu anche se l'aggiornamento non l'ha fatto
        $out = '';
        if (Tools::isSubmit('submitSeoPilot')) {
            $route = trim(Tools::getValue(self::CFG_ROUTE), '/ ');
            if (!preg_match('#^[a-z0-9][a-z0-9/_-]*$#i', $route)) {
                $out .= $this->displayError($this->l('Percorso del blog non valido.'));
            } else {
                Configuration::updateValue(self::CFG_ROUTE, $route);
                Configuration::updateValue(self::CFG_PER_PAGE, max(1, (int) Tools::getValue(self::CFG_PER_PAGE)));
                $title = [];
                $desc = [];
                foreach (Language::getLanguages(false) as $l) {
                    $title[$l['id_lang']] = Tools::getValue(self::CFG_BLOG_TITLE . '_' . $l['id_lang']);
                    $desc[$l['id_lang']] = Tools::getValue(self::CFG_BLOG_DESC . '_' . $l['id_lang']);
                }
                Configuration::updateValue(self::CFG_BLOG_TITLE, $title);
                Configuration::updateValue(self::CFG_BLOG_DESC, $desc);
                $panel = trim((string) Tools::getValue(self::CFG_PANEL_URL));
                Configuration::updateValue(self::CFG_PANEL_URL, preg_match('#^https://#', $panel) ? $panel : '');
                $prio = (int) Tools::getValue(self::CFG_PRIORITY);
                Configuration::updateValue(self::CFG_PRIORITY, $prio);
                $this->applyRoutePriority($prio);
                $out .= $this->displayConfirmation($this->l('Impostazioni salvate.'));
            }
        }
        if (Tools::isSubmit('submitJumpBlogConnect')) {
            try {
                $r = $this->bridgeConnect(trim((string) Tools::getValue('jb_code')));
                $out .= $this->displayConfirmation(sprintf($this->l('Negozio collegato a Jump Blog (lingue: %s). Apri Jump Blog dal menu di sinistra.'), implode(', ', $r['languages'])));
            } catch (Exception $e) {
                $out .= $this->displayError($e->getMessage());
            }
        }
        if (Tools::isSubmit('submitSeoPilotNewKey')) {
            Configuration::updateValue(self::CFG_API_KEY, bin2hex(random_bytes(24)));
            $out .= $this->displayConfirmation($this->l('Nuovo codice di collegamento generato: ricollega il negozio in Jump Blog.'));
        }
        return $out . $this->renderInfo() . $this->renderForm();
    }

    /** Collega il negozio a Jump Blog con il codice copiato dal pannello. */
    public function bridgeConnect($code)
    {
        if (!preg_match('#^JB1-([A-Za-z0-9_-]+)$#', $code, $mm)) {
            throw new Exception($this->l('Codice non valido: copialo da Jump Blog > Impostazioni > Collega il sito.'));
        }
        $raw = base64_decode(strtr($mm[1], '-_', '+/'));
        if (!$raw || strpos($raw, '|') === false) {
            throw new Exception($this->l('Codice non valido.'));
        }
        list($platform, $token) = explode('|', $raw, 2);
        if (!preg_match('#^https://#', $platform)) {
            throw new Exception($this->l('Codice non valido (indirizzo).'));
        }
        $body = json_encode([
            'token' => $token,
            'shop_url' => rtrim($this->context->link->getBaseLink(), '/'),
            'api_url' => $this->context->link->getModuleLink($this->name, 'api', [], true),
            'api_key' => Configuration::get(self::CFG_API_KEY),
            'name' => Configuration::get('PS_SHOP_NAME'),
            'platform' => 'prestashop',
        ]);
        $ch = curl_init(rtrim($platform, '/') . '/?r=bridge');
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 60,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json']]);
        $res = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        $data = json_decode((string) $res, true);
        if (!is_array($data) || empty($data['ok'])) {
            throw new Exception($this->l('Collegamento non riuscito: ') . (is_array($data) && !empty($data['error']) ? $data['error'] : ($err ?: 'risposta non valida')));
        }
        Configuration::updateValue(self::CFG_PANEL_URL, rtrim($platform, '/') . '/');
        Configuration::updateValue(self::CFG_CONNECTED, date('Y-m-d H:i:s'));
        $this->installMenu();

        return $data;
    }

    protected function renderInfo()
    {
        $count = (int) Db::getInstance()->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'seopilot_post` WHERE id_shop=' . (int) $this->context->shop->id);
        $apiUrl = $this->context->link->getModuleLink($this->name, 'api', [], true);
        $connected = Configuration::get(self::CFG_CONNECTED);
        $html = '<div class="panel"><h3><i class="icon-link"></i> ' . $this->l('Collega a Jump Blog') . '</h3>'
            . ($connected ? '<p class="alert alert-success">' . sprintf($this->l('Collegato a Jump Blog dal %s.'), htmlspecialchars($connected)) . ' <a href="' . htmlspecialchars($this->context->link->getAdminLink('AdminSeoPilot')) . '">' . $this->l('Apri Jump Blog') . '</a></p>' : '')
            . '<p>' . $this->l('In Jump Blog vai su Impostazioni > Collega il sito, copia il codice e incollalo qui.') . '</p>'
            . '<form method="post" class="form-inline"><input type="text" name="jb_code" class="form-control" style="width:420px" placeholder="JB1-..." autocomplete="off"> '
            . '<button class="btn btn-primary" name="submitJumpBlogConnect">' . $this->l('Collega') . '</button></form></div>';
        $html .= '<div class="panel"><h3>' . $this->l('Collegamento manuale (avanzato)') . '</h3>'
            . '<p>' . $this->l('Serve solo se il collegamento con il codice non funziona: copia questi due dati in Jump Blog.') . '</p>'
            . '<p><b>' . $this->l('Indirizzo di collegamento del negozio') . ':</b> <code>' . htmlspecialchars($apiUrl) . '</code></p>'
            . '<p><b>' . $this->l('Codice di collegamento del negozio') . ':</b> <code>' . htmlspecialchars(Configuration::get(self::CFG_API_KEY)) . '</code></p>'
            . '<p><b>' . $this->l('Articoli nel blog') . ':</b> ' . $count . ' &nbsp; <a target="_blank" href="' . htmlspecialchars($this->getBlogUrl()) . '">' . $this->l('Apri il blog') . '</a></p>'
            . '<form method="post"><button class="btn btn-default" name="submitSeoPilotNewKey" onclick="return confirm(\'' . $this->l('Generare un nuovo codice? Jump Blog smetterà di funzionare finché non ricolleghi il negozio.') . '\')">' . $this->l('Genera nuovo codice') . '</button></form></div>';

        return $html;
    }

    protected function renderForm()
    {
        $langs = Language::getLanguages(false);
        $fields = [
            'form' => [
                'legend' => ['title' => $this->l('Impostazioni del blog'), 'icon' => 'icon-cogs'],
                'input' => [
                    ['type' => 'text', 'label' => $this->l('Percorso del blog'), 'name' => self::CFG_ROUTE, 'desc' => $this->l('Es. "blog" = /blog. Non cambiarlo se gli articoli sono già indicizzati.')],
                    ['type' => 'text', 'label' => $this->l('Indirizzo di Jump Blog'), 'name' => self::CFG_PANEL_URL,
                        'desc' => $this->l('Si imposta da solo quando colleghi il negozio con il codice.')],
                    ['type' => 'text', 'label' => $this->l('Articoli per pagina'), 'name' => self::CFG_PER_PAGE, 'class' => 'fixed-width-sm'],
                    ['type' => 'switch', 'label' => $this->l('Priorità sul percorso del blog'), 'name' => self::CFG_PRIORITY, 'is_bool' => true,
                        'desc' => $this->l('Attivalo se un altro modulo (es. il blog del tema) usa lo stesso percorso: /blog e /blog?post=... verranno serviti da Jump Blog.'),
                        'values' => [['id' => 'p_on', 'value' => 1, 'label' => $this->l('Sì')], ['id' => 'p_off', 'value' => 0, 'label' => $this->l('No')]]],
                    ['type' => 'text', 'label' => $this->l('Titolo del blog (SEO)'), 'name' => self::CFG_BLOG_TITLE, 'lang' => true],
                    ['type' => 'textarea', 'label' => $this->l('Descrizione del blog (SEO)'), 'name' => self::CFG_BLOG_DESC, 'lang' => true],
                ],
                'submit' => ['title' => $this->l('Salva'), 'name' => 'submitSeoPilot'],
            ],
        ];
        $h = new HelperForm();
        $h->module = $this;
        $h->name_controller = $this->name;
        $h->token = Tools::getAdminTokenLite('AdminModules');
        $h->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $h->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');
        $h->allow_employee_form_lang = (int) Configuration::get('PS_LANG_DEFAULT');
        $h->languages = array_map(function ($l) {
            $l['is_default'] = (int) ($l['id_lang'] == Configuration::get('PS_LANG_DEFAULT'));

            return $l;
        }, $langs);
        $h->fields_value[self::CFG_ROUTE] = self::route();
        $h->fields_value[self::CFG_PER_PAGE] = (int) Configuration::get(self::CFG_PER_PAGE) ?: 12;
        $h->fields_value[self::CFG_PRIORITY] = (int) Configuration::get(self::CFG_PRIORITY);
        $h->fields_value[self::CFG_PANEL_URL] = (string) Configuration::get(self::CFG_PANEL_URL);
        foreach ($langs as $l) {
            $h->fields_value[self::CFG_BLOG_TITLE][$l['id_lang']] = Tools::getValue(self::CFG_BLOG_TITLE . '_' . $l['id_lang'], Configuration::get(self::CFG_BLOG_TITLE, $l['id_lang']));
            $h->fields_value[self::CFG_BLOG_DESC][$l['id_lang']] = Tools::getValue(self::CFG_BLOG_DESC . '_' . $l['id_lang'], Configuration::get(self::CFG_BLOG_DESC, $l['id_lang']));
        }

        return $h->generateForm([$fields]);
    }
}
