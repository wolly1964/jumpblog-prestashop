<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/** 1.2.0: voce "Jump Blog" nel menu di sinistra del back office. */
function upgrade_module_1_2_0($module)
{
    return $module->installMenu();
}
