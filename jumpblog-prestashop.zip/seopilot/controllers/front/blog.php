<?php
/**
 * Blog: elenco articoli (/blog) e articolo singolo (/blog?post=slug oppure /blog/slug).
 */
class SeoPilotBlogModuleFrontController extends ModuleFrontController
{
    /** @var SeoPilot */
    public $module;

    protected $post;
    protected $page = 1;
    protected $pages = 1;
    protected $is404 = false;

    public function init()
    {
        parent::init();
        $slug = trim((string) Tools::getValue('post'));
        $idLang = (int) $this->context->language->id;
        $idShop = (int) $this->context->shop->id;

        if ($slug !== '') {
            $this->post = SeoPilotPost::getBySlug($slug, $idLang, $idShop);
            if (!$this->post) {
                // Lo slug esiste in un'altra lingua: porta alla versione di questa lingua, se c'è.
                $id = SeoPilotPost::findIdBySlugAnyLang($slug, $idShop);
                $rows = $id ? SeoPilotPost::getLangRows($id) : [];
                if (isset($rows[$idLang])) {
                    Tools::redirect($this->module->getPostUrl($rows[$idLang]['slug'], $idLang), __PS_BASE_URI__, null, 'HTTP/1.1 301 Moved Permanently');
                }
                $this->notFound();
            }
        } else {
            $this->page = max(1, (int) Tools::getValue('page', 1));
            $per = (int) Configuration::get(SeoPilot::CFG_PER_PAGE) ?: 12;
            $this->pages = max(1, (int) ceil(SeoPilotPost::countPublished($idLang, $idShop) / $per));
            if ($this->page > $this->pages) {
                $this->notFound();
            }
        }
    }

    protected function notFound()
    {
        header('HTTP/1.1 404 Not Found');
        header('Status: 404 Not Found');
        $this->errors[] = $this->module->l('Articolo non trovato.', 'blog');
        $this->post = null;
        $this->is404 = true;
    }

    public function initContent()
    {
        parent::initContent();
        $idLang = (int) $this->context->language->id;
        $idShop = (int) $this->context->shop->id;

        if (!empty($this->is404)) {
            $this->setTemplate('errors/404');

            return;
        }

        if ($this->post) {
            $p = $this->post;
            $this->context->smarty->assign([
                'sp_post' => $p,
                'sp_image' => SeoPilot::imageUrl($p['image']),
                'sp_blog_url' => $this->module->getBlogUrl($idLang),
                'sp_jsonld' => $this->jsonLdPost($p),
                'sp_related' => array_values(array_filter(
                    $this->decorate(SeoPilotPost::getPublished($idLang, $idShop, 0, 4), $idLang),
                    function ($r) use ($p) { return (int) $r['id_seopilot_post'] !== (int) $p['id_seopilot_post']; }
                )),
            ]);
            $this->setTemplate('module:seopilot/views/templates/front/post.tpl');

            return;
        }

        if (!SeoPilotPost::countPublished($idLang, $idShop)) {
            // il tema potrebbe non stampare il meta robots: lo mandiamo anche come header
            header('X-Robots-Tag: noindex, follow');
        }
        $per = (int) Configuration::get(SeoPilot::CFG_PER_PAGE) ?: 12;
        $posts = $this->decorate(SeoPilotPost::getPublished($idLang, $idShop, ($this->page - 1) * $per, $per), $idLang);
        $this->context->smarty->assign([
            'sp_posts' => $posts,
            'sp_title' => $this->blogTitle(),
            'sp_desc' => Configuration::get(SeoPilot::CFG_BLOG_DESC, $idLang),
            'sp_page' => $this->page,
            'sp_pages' => $this->pages,
            'sp_prev' => $this->page > 1 ? $this->module->getBlogUrl($idLang, $this->page - 1) : null,
            'sp_next' => $this->page < $this->pages ? $this->module->getBlogUrl($idLang, $this->page + 1) : null,
            'sp_jsonld' => $this->jsonLdBlog($posts),
        ]);
        $this->setTemplate('module:seopilot/views/templates/front/list.tpl');
    }

    protected function decorate(array $rows, $idLang)
    {
        foreach ($rows as &$r) {
            $r['url'] = $this->module->getPostUrl($r['slug'], $idLang);
            $r['image_url'] = SeoPilot::imageUrl($r['image']);
            $r['date_iso'] = date('c', strtotime($r['date_publish']));
        }

        return $rows;
    }

    protected function blogTitle()
    {
        $t = Configuration::get(SeoPilot::CFG_BLOG_TITLE, (int) $this->context->language->id);

        return $t ?: 'Blog';
    }

    public function getTemplateVarPage()
    {
        $page = parent::getTemplateVarPage();
        if (!empty($this->is404)) {
            return $page;
        }
        if ($this->post) {
            $page['meta']['title'] = $this->post['meta_title'] ?: $this->post['title'];
            $page['meta']['description'] = $this->post['meta_description'] ?: $this->post['excerpt'];
        } else {
            $title = $this->blogTitle();
            $page['meta']['title'] = $this->page > 1 ? $title . ' - ' . $this->page : $title;
            $page['meta']['description'] = (string) Configuration::get(SeoPilot::CFG_BLOG_DESC, (int) $this->context->language->id);
        }
        // Blog vuoto in questa lingua: niente indicizzazione (pagina senza contenuto).
        $empty = !$this->post && !SeoPilotPost::countPublished((int) $this->context->language->id, (int) $this->context->shop->id);
        $page['meta']['robots'] = $empty ? 'noindex' : 'index';
        $page['page_name'] = 'module-seopilot-blog';

        return $page;
    }

    public function getCanonicalURL()
    {
        $idLang = (int) $this->context->language->id;
        if ($this->post) {
            return $this->module->getPostUrl($this->post['slug'], $idLang);
        }

        return $this->module->getBlogUrl($idLang, $this->page);
    }

    /** hreflang: solo le lingue in cui l'articolo esiste davvero. */
    protected function getAlternativeLangsUrl()
    {
        $out = [];
        $languages = Language::getLanguages(true, $this->context->shop->id);
        if (count($languages) < 2) {
            return $out;
        }
        $rows = $this->post ? SeoPilotPost::getLangRows($this->post['id_seopilot_post']) : null;
        foreach ($languages as $l) {
            if ($rows !== null) {
                if (!isset($rows[$l['id_lang']])) {
                    continue;
                }
                $out[$l['language_code']] = $this->module->getPostUrl($rows[$l['id_lang']]['slug'], (int) $l['id_lang']);
            } elseif (SeoPilotPost::countPublished((int) $l['id_lang'], (int) $this->context->shop->id)) {
                $out[$l['language_code']] = $this->module->getBlogUrl((int) $l['id_lang']);
            }
        }

        return count($out) > 1 ? $out : [];
    }

    public function getBreadcrumbLinks()
    {
        $b = parent::getBreadcrumbLinks();
        $b['links'][] = ['title' => $this->blogTitle(), 'url' => $this->module->getBlogUrl()];
        if ($this->post) {
            $b['links'][] = ['title' => $this->post['title'], 'url' => $this->getCanonicalURL()];
        }

        return $b;
    }

    protected function jsonLdPost(array $p)
    {
        $data = [
            '@context' => 'https://schema.org',
            '@type' => 'BlogPosting',
            'headline' => $p['title'],
            'description' => $p['meta_description'] ?: $p['excerpt'],
            'datePublished' => date('c', strtotime($p['date_publish'])),
            'dateModified' => date('c', strtotime($p['date_upd'])),
            'mainEntityOfPage' => $this->getCanonicalURL(),
            'inLanguage' => $this->context->language->language_code,
            'publisher' => ['@type' => 'Organization', 'name' => Configuration::get('PS_SHOP_NAME')],
        ];
        if ($p['image']) {
            $data['image'] = SeoPilot::imageUrl($p['image']);
        }

        return json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG);
    }

    protected function jsonLdBlog(array $posts)
    {
        $items = [];
        foreach ($posts as $p) {
            $items[] = ['@type' => 'BlogPosting', 'headline' => $p['title'], 'url' => $p['url'], 'datePublished' => $p['date_iso']];
        }

        return json_encode([
            '@context' => 'https://schema.org',
            '@type' => 'Blog',
            'name' => $this->blogTitle(),
            'url' => $this->module->getBlogUrl(),
            'blogPost' => $items,
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG);
    }
}
