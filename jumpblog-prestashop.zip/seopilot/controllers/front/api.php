<?php
/**
 * API per la piattaforma Jump Blog.
 * Autenticazione: header "Authorization: Bearer <chiave>" (oppure X-SeoPilot-Key).
 * Richiesta: POST JSON {"action": "...", ...}
 *
 * Azioni: ping, site, catalog, publish, unpublish, list, get
 * Jump SEO (dalla 1.4.0): seo_products, seo_product, seo_save
 */
class SeoPilotApiModuleFrontController extends ModuleFrontController
{
    /** @var SeoPilot */
    public $module;
    public $ajax = true;
    public $ssl = true;
    protected $content_only = true;

    /** L'API deve funzionare anche con il negozio in manutenzione. */
    protected function displayMaintenancePage()
    {
    }

    public function initContent()
    {
        // niente template: risponde solo JSON
    }

    public function postProcess()
    {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        header('X-Robots-Tag: noindex');
        try {
            $this->authenticate();
            $in = json_decode(Tools::file_get_contents('php://input'), true);
            if (!is_array($in)) {
                $in = $_POST;
            }
            $action = isset($in['action']) ? (string) $in['action'] : 'ping';
            switch ($action) {
                case 'ping':
                    $out = $this->ping();
                    break;
                case 'site':
                    $out = $this->site();
                    break;
                case 'catalog':
                    $out = $this->catalog($in);
                    break;
                case 'publish':
                    $out = $this->publish($in);
                    break;
                case 'unpublish':
                    $out = $this->unpublish($in);
                    break;
                case 'list':
                    $out = $this->listPosts($in);
                    break;
                case 'get':
                    $out = $this->getPost($in);
                    break;
                case 'seo_products':
                    $out = $this->seoProducts($in);
                    break;
                case 'seo_product':
                    $out = $this->seoProduct($in);
                    break;
                case 'seo_save':
                    $out = $this->seoSave($in);
                    break;
                default:
                    throw new SeoPilotApiException('Azione sconosciuta: ' . $action, 400);
            }
            $this->send(['ok' => true] + $out);
        } catch (SeoPilotApiException $e) {
            $this->send(['ok' => false, 'error' => $e->getMessage()], $e->getCode());
        } catch (Exception $e) {
            $this->send(['ok' => false, 'error' => 'Errore interno: ' . $e->getMessage()], 500);
        }
    }

    protected function send(array $data, $code = 200)
    {
        http_response_code($code ?: 500);
        exit(json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    protected function authenticate()
    {
        $key = (string) Configuration::get(SeoPilot::CFG_API_KEY);
        $given = '';
        $auth = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']) ? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] : '');
        if (stripos($auth, 'Bearer ') === 0) {
            $given = trim(substr($auth, 7));
        } elseif (!empty($_SERVER['HTTP_X_SEOPILOT_KEY'])) {
            $given = trim($_SERVER['HTTP_X_SEOPILOT_KEY']);
        }
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            throw new SeoPilotApiException('Usa POST.', 405);
        }
        if ($key === '' || $given === '' || !hash_equals($key, $given)) {
            throw new SeoPilotApiException('Chiave API non valida.', 401);
        }
    }

    protected function languages()
    {
        $out = [];
        foreach (Language::getLanguages(true, $this->context->shop->id) as $l) {
            $out[] = ['id' => (int) $l['id_lang'], 'iso' => $l['iso_code'], 'code' => $l['language_code'], 'name' => $l['name']];
        }

        return $out;
    }

    protected function langIdByIso($iso)
    {
        $id = (int) Language::getIdByIso($iso);
        if (!$id) {
            throw new SeoPilotApiException('Lingua non presente nel negozio: ' . $iso, 400);
        }

        return $id;
    }

    protected function ping()
    {
        return [
            'module_version' => $this->module->version,
            'ps_version' => _PS_VERSION_,
            'shop' => Configuration::get('PS_SHOP_NAME'),
            'url' => $this->context->link->getBaseLink(),
            'blog_url' => $this->module->getBlogUrl((int) Configuration::get('PS_LANG_DEFAULT')),
            'languages' => $this->languages(),
            'default_lang' => Language::getIsoById((int) Configuration::get('PS_LANG_DEFAULT')),
        ];
    }

    /** Dati per capire il negozio: nome, meta della home, lingue. */
    protected function site()
    {
        $out = $this->ping();
        $out['home'] = [];
        foreach (Language::getLanguages(true, $this->context->shop->id) as $l) {
            $meta = Meta::getMetaByPage('index', (int) $l['id_lang']);
            $out['home'][$l['iso_code']] = [
                'title' => isset($meta['title']) ? $meta['title'] : '',
                'description' => isset($meta['description']) ? $meta['description'] : '',
            ];
        }

        return $out;
    }

    /**
     * Categorie e prodotti con nome e URL, per argomenti e link interni.
     * Parametri: lang (iso), products (max prodotti, default 300)
     */
    protected function catalog(array $in)
    {
        $iso = isset($in['lang']) ? (string) $in['lang'] : Language::getIsoById((int) Configuration::get('PS_LANG_DEFAULT'));
        $idLang = $this->langIdByIso($iso);
        $idShop = (int) $this->context->shop->id;
        $limit = min(2000, max(0, isset($in['products']) ? (int) $in['products'] : 300));
        $link = $this->context->link;

        $cats = Db::getInstance()->executeS(
            'SELECT c.id_category, c.id_parent, c.level_depth, cl.name, cl.link_rewrite, cl.meta_description,
                    (SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'category_product` cp
                       INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps ON ps.id_product = cp.id_product AND ps.id_shop = ' . $idShop . ' AND ps.active = 1
                     WHERE cp.id_category = c.id_category) AS nb_products
             FROM `' . _DB_PREFIX_ . 'category` c
             INNER JOIN `' . _DB_PREFIX_ . 'category_shop` cs ON cs.id_category = c.id_category AND cs.id_shop = ' . $idShop . '
             INNER JOIN `' . _DB_PREFIX_ . 'category_lang` cl ON cl.id_category = c.id_category AND cl.id_lang = ' . $idLang . ' AND cl.id_shop = ' . $idShop . '
             WHERE c.active = 1 AND c.level_depth > 1
             ORDER BY c.level_depth, cs.position'
        ) ?: [];
        $categories = [];
        foreach ($cats as $c) {
            if ((int) $c['nb_products'] === 0) {
                continue;
            }
            $categories[] = [
                'id' => (int) $c['id_category'],
                'parent' => (int) $c['id_parent'],
                'depth' => (int) $c['level_depth'],
                'name' => $c['name'],
                'products' => (int) $c['nb_products'],
                'url' => $link->getCategoryLink((int) $c['id_category'], $c['link_rewrite'], $idLang),
            ];
        }

        $products = [];
        $imgType = ImageType::getFormattedName('large');
        if ($limit > 0) {
            $rows = Db::getInstance()->executeS(
                'SELECT p.id_product, pl.name, pl.link_rewrite, ps.id_category_default, sa.quantity,
                        (SELECT ims.id_image FROM `' . _DB_PREFIX_ . 'image_shop` ims WHERE ims.id_product = p.id_product AND ims.id_shop = ' . $idShop . ' AND ims.cover = 1 LIMIT 1) AS id_cover
                 FROM `' . _DB_PREFIX_ . 'product` p
                 INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps ON ps.id_product = p.id_product AND ps.id_shop = ' . $idShop . ' AND ps.active = 1 AND ps.visibility IN (\'both\',\'catalog\')
                 INNER JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON pl.id_product = p.id_product AND pl.id_lang = ' . $idLang . ' AND pl.id_shop = ' . $idShop . '
                 LEFT JOIN `' . _DB_PREFIX_ . 'stock_available` sa ON sa.id_product = p.id_product AND sa.id_product_attribute = 0 AND sa.id_shop = ' . $idShop . '
                 ORDER BY (sa.quantity > 0) DESC, ps.date_upd DESC
                 LIMIT ' . $limit
            ) ?: [];
            foreach ($rows as $r) {
                $products[] = [
                    'id' => (int) $r['id_product'],
                    'name' => $r['name'],
                    'category' => (int) $r['id_category_default'],
                    'in_stock' => (int) $r['quantity'] > 0,
                    'url' => $link->getProductLink((int) $r['id_product'], $r['link_rewrite'], null, null, $idLang),
                    'image' => $r['id_cover'] ? $link->getImageLink($r['link_rewrite'], (int) $r['id_product'] . '-' . (int) $r['id_cover'], $imgType) : null,
                ];
            }
        }

        return ['lang' => $iso, 'categories' => $categories, 'products' => $products];
    }

    /**
     * Pubblica o aggiorna un articolo.
     * {"action":"publish","external_id":"123","date_publish":"2026-11-20 08:00:00","active":true,
     *  "image_url":"https://...","translations":{"it":{"title","slug","excerpt","content","meta_title","meta_description","keyword","image_alt"}, ...}}
     */
    protected function publish(array $in)
    {
        if (empty($in['external_id']) || empty($in['translations']) || !is_array($in['translations'])) {
            throw new SeoPilotApiException('Servono external_id e translations.', 400);
        }
        $langs = [];
        foreach ($in['translations'] as $iso => $t) {
            if (empty($t['title']) || empty($t['content'])) {
                throw new SeoPilotApiException('Titolo o contenuto mancante per la lingua ' . $iso, 400);
            }
            $langs[$this->langIdByIso($iso)] = [
                'title' => Tools::substr(strip_tags($t['title']), 0, 255),
                'slug' => isset($t['slug']) ? Tools::substr($t['slug'], 0, 180) : '',
                'excerpt' => isset($t['excerpt']) ? strip_tags($t['excerpt']) : '',
                'content' => SeoPilotContent::cleanContent($t['content']),
                'meta_title' => isset($t['meta_title']) ? Tools::substr(strip_tags($t['meta_title']), 0, 255) : '',
                'meta_description' => isset($t['meta_description']) ? Tools::substr(strip_tags($t['meta_description']), 0, 500) : '',
                'keyword' => isset($t['keyword']) ? Tools::substr(strip_tags($t['keyword']), 0, 255) : '',
                'image_alt' => isset($t['image_alt']) ? Tools::substr(strip_tags($t['image_alt']), 0, 255) : '',
            ];
        }
        $image = '';
        if (!empty($in['image_url']) && preg_match('#^https://#', $in['image_url'])) {
            $first = reset($in['translations']);
            $importer = new SeoPilotImageFetcher();
            $image = $importer->fetch($in['image_url'], isset($first['slug']) ? $first['slug'] : $in['external_id']);
        }
        $date = !empty($in['date_publish']) ? date('Y-m-d H:i:s', strtotime($in['date_publish'])) : '';
        list($id, $created) = SeoPilotPost::upsert((int) $this->context->shop->id, [
            'external_id' => (string) $in['external_id'],
            'source' => 'platform',
            'image' => $image,
            'active' => !isset($in['active']) || $in['active'],
            'date_publish' => $date,
        ], $langs);

        $urls = [];
        foreach (SeoPilotPost::getLangRows($id) as $idLang => $row) {
            $urls[Language::getIsoById($idLang)] = $this->module->getPostUrl($row['slug'], $idLang);
        }

        return ['id' => $id, 'created' => $created, 'urls' => $urls];
    }

    protected function unpublish(array $in)
    {
        $id = !empty($in['external_id']) ? SeoPilotPost::getIdByExternal((string) $in['external_id'], (int) $this->context->shop->id) : 0;
        if (!$id) {
            throw new SeoPilotApiException('Articolo non trovato.', 404);
        }
        Db::getInstance()->update('seopilot_post', ['active' => 0, 'date_upd' => date('Y-m-d H:i:s')], 'id_seopilot_post = ' . (int) $id);

        return ['id' => $id];
    }

    /**
     * Sincronizza gli articoli di un blog esterno già configurato (solo negozi esistenti).
     * Usa il token salvato nella configurazione del modulo.
     */
    /* ======================= Jump SEO: prodotti ======================= */

    /** Lingue attive del negozio: id_lang => iso */
    protected function seoLangs()
    {
        $out = [];
        foreach (Language::getLanguages(true, $this->context->shop->id) as $l) {
            $out[(int) $l['id_lang']] = (string) $l['iso_code'];
        }

        return $out;
    }

    protected function seoWhere()
    {
        return 'ps.id_shop = ' . (int) $this->context->shop->id . ' AND ps.active = 1 AND ps.visibility IN (\'both\',\'catalog\',\'search\')';
    }

    /**
     * Elenco prodotti attivi e visibili, dal più recente.
     * {"action":"seo_products","page":1,"per":30}
     */
    protected function seoProducts(array $in)
    {
        $per = min(200, max(1, isset($in['per']) ? (int) $in['per'] : 30));
        $page = max(1, isset($in['page']) ? (int) $in['page'] : 1);
        $db = Db::getInstance();
        $rows = $db->executeS('SELECT ps.id_product FROM `' . _DB_PREFIX_ . 'product_shop` ps WHERE ' . $this->seoWhere()
            . ' ORDER BY ps.id_product DESC LIMIT ' . (($page - 1) * $per) . ',' . $per) ?: [];
        $out = [];
        foreach ($rows as $r) {
            $out[] = $this->seoMap((int) $r['id_product']);
        }

        return [
            'products' => $out,
            'total' => (int) $db->getValue('SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'product_shop` ps WHERE ' . $this->seoWhere()),
        ];
    }

    /** Un prodotto: {"action":"seo_product","id":123} */
    protected function seoProduct(array $in)
    {
        $id = isset($in['id']) ? (int) $in['id'] : 0;
        if (!$id || !Db::getInstance()->getValue('SELECT ps.id_product FROM `' . _DB_PREFIX_ . 'product_shop` ps WHERE ps.id_product = ' . $id . ' AND ' . $this->seoWhere())) {
            throw new SeoPilotApiException('Prodotto non trovato, disattivato o nascosto: Jump SEO non lo modifica.', 404);
        }

        return ['product' => $this->seoMap($id)];
    }

    /** Prodotto PrestaShop -> forma usata da Jump SEO (testi per lingua iso). */
    protected function seoMap($id)
    {
        $id = (int) $id;
        $db = Db::getInstance();
        $idShop = (int) $this->context->shop->id;
        $idDefault = (int) Configuration::get('PS_LANG_DEFAULT');
        $langs = $this->seoLangs();
        $link = $this->context->link;
        $p = $db->getRow('SELECT p.id_product, p.reference, p.id_manufacturer, ps.date_add FROM `' . _DB_PREFIX_ . 'product` p
            INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps ON ps.id_product = p.id_product AND ps.id_shop = ' . $idShop . '
            WHERE p.id_product = ' . $id);
        $name = $desc = $mt = $md = $urls = [];
        $rewrite = '';
        foreach ($db->executeS('SELECT id_lang, name, description, description_short, meta_title, meta_description, link_rewrite
            FROM `' . _DB_PREFIX_ . 'product_lang` WHERE id_product = ' . $id . ' AND id_shop = ' . $idShop) ?: [] as $r) {
            $il = (int) $r['id_lang'];
            if (!isset($langs[$il])) {
                continue;
            }
            $iso = $langs[$il];
            $name[$iso] = (string) $r['name'];
            $desc[$iso] = trim(strip_tags((string) $r['description'])) !== '' ? (string) $r['description'] : (string) $r['description_short'];
            $mt[$iso] = (string) $r['meta_title'];
            $md[$iso] = (string) $r['meta_description'];
            $urls[$iso] = $link->getProductLink($id, $r['link_rewrite'], null, null, $il);
            if ($il === $idDefault || $rewrite === '') {
                $rewrite = (string) $r['link_rewrite'];
            }
        }
        $images = [];
        $imgType = ImageType::getFormattedName('large');
        $imgs = $db->executeS('SELECT i.id_image, i.position FROM `' . _DB_PREFIX_ . 'image` i
            INNER JOIN `' . _DB_PREFIX_ . 'image_shop` ims ON ims.id_image = i.id_image AND ims.id_shop = ' . $idShop . '
            WHERE i.id_product = ' . $id . ' ORDER BY i.position') ?: [];
        $legends = [];
        if ($imgs) {
            foreach ($db->executeS('SELECT id_image, id_lang, legend FROM `' . _DB_PREFIX_ . 'image_lang` WHERE id_image IN (' . implode(',', array_map(function ($i) { return (int) $i['id_image']; }, $imgs)) . ')') ?: [] as $r) {
                if (isset($langs[(int) $r['id_lang']])) {
                    $legends[(int) $r['id_image']][$langs[(int) $r['id_lang']]] = (string) $r['legend'];
                }
            }
        }
        foreach ($imgs as $i) {
            $iid = (int) $i['id_image'];
            $images[] = [
                'id' => (string) $iid,
                'src' => $link->getImageLink($rewrite, $id . '-' . $iid, $imgType),
                'alt' => isset($legends[$iid]) ? $legends[$iid] : [],
                'position' => (int) $i['position'],
            ];
        }
        $cats = [];
        foreach ($db->executeS('SELECT cp.id_category, cl.id_lang, cl.name FROM `' . _DB_PREFIX_ . 'category_product` cp
            INNER JOIN `' . _DB_PREFIX_ . 'category_lang` cl ON cl.id_category = cp.id_category AND cl.id_shop = ' . $idShop . '
            INNER JOIN `' . _DB_PREFIX_ . 'category` c ON c.id_category = cp.id_category AND c.level_depth > 1
            WHERE cp.id_product = ' . $id) ?: [] as $r) {
            if (isset($langs[(int) $r['id_lang']])) {
                $cats[(int) $r['id_category']]['name'][$langs[(int) $r['id_lang']]] = (string) $r['name'];
            }
        }
        $tags = '';
        $pt = Tag::getProductTags($id);
        if (is_array($pt) && !empty($pt[$idDefault])) {
            $tags = implode(', ', $pt[$idDefault]);
        }
        $defIso = isset($langs[$idDefault]) ? $langs[$idDefault] : '';

        return [
            'id' => (string) $id,
            'name' => $name,
            'description' => $desc,
            'seo_title' => $mt,
            'seo_description' => $md,
            'images' => $images,
            'categories' => array_values($cats),
            'variants' => [['price' => (string) round((float) Product::getPriceStatic($id, true), 2)]],
            'brand' => $p && (int) $p['id_manufacturer'] ? (string) Manufacturer::getNameById((int) $p['id_manufacturer']) : '',
            'tags' => $tags,
            'handle' => '',
            'permalink' => isset($urls[$defIso]) ? $urls[$defIso] : (string) reset($urls),
            'created' => $p ? (string) $p['date_add'] : '',
            'reference' => $p ? (string) $p['reference'] : '',
        ];
    }

    /**
     * Salva i testi SEO di un prodotto. Tocca solo i campi inviati e solo le lingue indicate.
     * {"action":"seo_save","id":123,"description":{"it":"..."},"meta_title":{"it":"..."},"meta_description":{"it":"..."},
     *  "images":[{"id":456,"legend":{"it":"..."}}]}
     */
    protected function seoSave(array $in)
    {
        $id = isset($in['id']) ? (int) $in['id'] : 0;
        $this->seoProduct(['id' => $id]); // deve esistere ed essere visibile
        $db = Db::getInstance();
        $idShop = (int) $this->context->shop->id;
        $langs = array_flip($this->seoLangs()); // iso => id_lang
        $saved = 0;
        foreach (['description' => 0, 'meta_title' => 255, 'meta_description' => 512] as $col => $max) {
            if (!isset($in[$col]) || !is_array($in[$col])) {
                continue;
            }
            foreach ($in[$col] as $iso => $val) {
                if (!isset($langs[(string) $iso]) || !is_scalar($val)) {
                    continue;
                }
                $val = (string) $val;
                if ($max) {
                    $val = Tools::substr(trim(strip_tags($val)), 0, $max);
                }
                $db->update('product_lang', [$col => pSQL($val, $col === 'description')], 'id_product = ' . $id . ' AND id_lang = ' . (int) $langs[(string) $iso] . ' AND id_shop = ' . $idShop);
                ++$saved;
            }
        }
        $own = array_map('intval', array_column($db->executeS('SELECT id_image FROM `' . _DB_PREFIX_ . 'image` WHERE id_product = ' . $id) ?: [], 'id_image'));
        foreach (isset($in['images']) && is_array($in['images']) ? $in['images'] : [] as $im) {
            $iid = isset($im['id']) ? (int) $im['id'] : 0;
            if (!$iid || !in_array($iid, $own, true) || !isset($im['legend']) || !is_array($im['legend'])) {
                continue;
            }
            foreach ($im['legend'] as $iso => $val) {
                if (!isset($langs[(string) $iso]) || !is_scalar($val)) {
                    continue;
                }
                $db->update('image_lang', ['legend' => pSQL(Tools::substr(trim(strip_tags((string) $val)), 0, 128))], 'id_image = ' . $iid . ' AND id_lang = ' . (int) $langs[(string) $iso]);
                ++$saved;
            }
        }
        $db->update('product_shop', ['date_upd' => date('Y-m-d H:i:s')], 'id_product = ' . $id . ' AND id_shop = ' . $idShop);
        // niente hook actionProductUpdate: alcuni moduli SEO rileggono il form dell'admin e azzererebbero i loro campi
        try {
            Search::indexation(false, $id);
        } catch (Exception $e) {
        }

        return ['saved' => $saved, 'product' => $this->seoMap($id)];
    }

    /** Articolo completo in tutte le lingue (per tradurlo o arricchirlo). */
    protected function getPost(array $in)
    {
        $idShop = (int) $this->context->shop->id;
        $id = !empty($in['external_id']) ? SeoPilotPost::getIdByExternal((string) $in['external_id'], $idShop) : (int) (isset($in['id']) ? $in['id'] : 0);
        $row = $id ? Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'seopilot_post` WHERE id_seopilot_post = ' . (int) $id . ' AND id_shop = ' . $idShop) : null;
        if (!$row) {
            throw new SeoPilotApiException('Articolo non trovato.', 404);
        }
        $tr = [];
        foreach (SeoPilotPost::getLangRows($id) as $idLang => $l) {
            $iso = Language::getIsoById($idLang);
            $tr[$iso] = array_intersect_key($l, array_flip(['title', 'slug', 'excerpt', 'content', 'meta_title', 'meta_description', 'keyword', 'image_alt']));
            $tr[$iso]['url'] = $this->module->getPostUrl($l['slug'], $idLang);
        }

        return ['post' => [
            'id' => (int) $row['id_seopilot_post'], 'external_id' => $row['external_id'], 'source' => $row['source'],
            'date_publish' => $row['date_publish'], 'image' => SeoPilot::imageUrl($row['image']), 'active' => (int) $row['active'],
            'translations' => $tr,
        ]];
    }

    /** Elenco articoli già nel blog (titoli e parole chiave), per evitare doppioni. */
    protected function listPosts(array $in)
    {
        $iso = isset($in['lang']) ? (string) $in['lang'] : Language::getIsoById((int) Configuration::get('PS_LANG_DEFAULT'));
        $idLang = $this->langIdByIso($iso);
        $rows = Db::getInstance()->executeS(
            'SELECT p.id_seopilot_post, p.external_id, p.source, p.active, p.date_publish, pl.title, pl.slug, pl.keyword,
                    (SELECT GROUP_CONCAT(l2.id_lang) FROM `' . _DB_PREFIX_ . 'seopilot_post_lang` l2 WHERE l2.id_seopilot_post = p.id_seopilot_post) AS lang_ids,
                    (LENGTH(pl.content) - LENGTH(REPLACE(pl.content, \'<a \', \'\'))) / 3 AS links
             FROM `' . _DB_PREFIX_ . 'seopilot_post` p
             INNER JOIN `' . _DB_PREFIX_ . 'seopilot_post_lang` pl ON pl.id_seopilot_post = p.id_seopilot_post AND pl.id_lang = ' . $idLang . '
             WHERE p.id_shop = ' . (int) $this->context->shop->id . '
             ORDER BY p.date_publish DESC LIMIT 2000'
        ) ?: [];
        foreach ($rows as &$r) {
            $r['url'] = $this->module->getPostUrl($r['slug'], $idLang);
            $r['langs'] = array_values(array_map(function ($i) { return Language::getIsoById((int) $i); }, array_filter(explode(',', (string) $r['lang_ids']))));
            $r['links'] = (int) $r['links'];
            unset($r['lang_ids']);
        }

        return ['lang' => $iso, 'posts' => $rows];
    }
}

class SeoPilotApiException extends Exception
{
}
