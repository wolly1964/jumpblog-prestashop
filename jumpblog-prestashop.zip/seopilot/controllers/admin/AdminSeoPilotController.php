<?php
/**
 * Voce "Jump Blog" nel menu di sinistra: apre il pannello della piattaforma dentro il back office.
 */
class AdminSeoPilotController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
        $this->meta_title = 'Jump Blog';
    }

    public function initContent()
    {
        parent::initContent();
        $url = trim((string) Configuration::get(SeoPilot::CFG_PANEL_URL));
        $config = $this->context->link->getAdminLink('AdminModules', true, [], ['configure' => 'seopilot']);
        if ($url === '') {
            $this->content = '<div class="panel"><h3>Jump Blog</h3><p>'
                . $this->module->l('Il negozio non è ancora collegato a Jump Blog.', 'adminseopilotcontroller')
                . ' <a class="btn btn-primary" href="' . htmlspecialchars($config) . '">' . $this->module->l('Collegalo con il codice', 'adminseopilotcontroller') . '</a></p></div>';
        } else {
            $this->content = '<div style="margin:-10px -10px 0 -10px">'
                . '<p style="text-align:right;margin:0 10px 6px">'
                . '<a class="btn btn-default" target="_blank" rel="noopener" href="' . htmlspecialchars($url) . '"><i class="icon-external-link"></i> ' . $this->module->l('Apri in una nuova scheda', 'adminseopilotcontroller') . '</a> '
                . '<a class="btn btn-default" href="' . htmlspecialchars($config) . '"><i class="icon-cogs"></i> ' . $this->module->l('Impostazioni modulo', 'adminseopilotcontroller') . '</a></p>'
                . '<iframe src="' . htmlspecialchars($url) . '" style="width:100%;height:calc(100vh - 170px);min-height:600px;border:1px solid #ddd;border-radius:6px;background:#fff" title="Jump Blog"></iframe>'
                . '</div>';
        }
        $this->context->smarty->assign('content', $this->content);
    }
}
