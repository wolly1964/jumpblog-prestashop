<?php
/**
 * Scarica un'immagine e la salva in /img/seopilot/, convertita in WebP se possibile.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class SeoPilotImageFetcher
{
    public function fetch($url, $slug)
    {
        $data = self::http($url);
        if (!$data || strlen($data) < 100) {
            return '';
        }
        $dir = _PS_IMG_DIR_ . 'seopilot/';
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $name = Tools::str2url($slug);
        // Preferenza: WebP
        if (function_exists('imagecreatefromstring') && function_exists('imagewebp')) {
            $im = @imagecreatefromstring($data);
            if ($im) {
                imagepalettetotruecolor($im);
                imagealphablending($im, true);
                imagesavealpha($im, true);
                if (imagewebp($im, $dir . $name . '.webp', 85)) {
                    imagedestroy($im);

                    return $name . '.webp';
                }
                imagedestroy($im);
            }
        }
        $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
        $ext = in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif']) ? $ext : 'jpg';
        file_put_contents($dir . $name . '.' . $ext, $data);

        return $name . '.' . $ext;
    }

    public static function http($url)
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_USERAGENT => 'JumpBlog/1.0',
        ]);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);
        if ($body === false || $code >= 400) {
            throw new Exception('Download fallito (' . ($err ?: 'HTTP ' . $code) . '): ' . $url);
        }

        return $body;
    }
}
