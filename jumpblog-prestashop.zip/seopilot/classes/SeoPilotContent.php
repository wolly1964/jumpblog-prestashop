<?php
/**
 * Pulizia del contenuto HTML degli articoli ricevuti da Jump Blog.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class SeoPilotContent
{
    /** Toglie script e attributi pericolosi dal contenuto HTML. */
    public static function cleanContent($html)
    {
        $html = preg_replace('#<(script|style|iframe)\b[^>]*>.*?</\1>#is', '', $html);
        $html = preg_replace('#\son[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)#i', '', $html);
        $html = preg_replace('#(href|src)\s*=\s*(["\'])\s*javascript:[^"\']*\2#i', '$1="#"', $html);

        return trim($html);
    }
}
