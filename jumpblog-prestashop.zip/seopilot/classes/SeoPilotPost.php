<?php
/**
 * Accesso ai dati degli articoli (tabelle seopilot_post / seopilot_post_lang).
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class SeoPilotPost
{
    public static function table($lang = false)
    {
        return _DB_PREFIX_ . ($lang ? 'seopilot_post_lang' : 'seopilot_post');
    }

    public static function countPublished($idLang, $idShop)
    {
        return (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . self::table() . '` p
             INNER JOIN `' . self::table(true) . '` pl ON pl.id_seopilot_post = p.id_seopilot_post AND pl.id_lang = ' . (int) $idLang . '
             WHERE p.id_shop = ' . (int) $idShop . ' AND p.active = 1 AND p.date_publish <= NOW()'
        );
    }

    public static function getPublished($idLang, $idShop, $offset, $limit)
    {
        return Db::getInstance()->executeS(
            'SELECT p.*, pl.title, pl.slug, pl.excerpt, pl.meta_title, pl.meta_description, pl.image_alt
             FROM `' . self::table() . '` p
             INNER JOIN `' . self::table(true) . '` pl ON pl.id_seopilot_post = p.id_seopilot_post AND pl.id_lang = ' . (int) $idLang . '
             WHERE p.id_shop = ' . (int) $idShop . ' AND p.active = 1 AND p.date_publish <= NOW()
             ORDER BY p.date_publish DESC, p.id_seopilot_post DESC
             LIMIT ' . (int) $offset . ', ' . (int) $limit
        ) ?: [];
    }

    public static function getBySlug($slug, $idLang, $idShop)
    {
        $row = Db::getInstance()->getRow(
            'SELECT p.*, pl.*
             FROM `' . self::table() . '` p
             INNER JOIN `' . self::table(true) . '` pl ON pl.id_seopilot_post = p.id_seopilot_post AND pl.id_lang = ' . (int) $idLang . '
             WHERE p.id_shop = ' . (int) $idShop . ' AND p.active = 1 AND p.date_publish <= NOW()
               AND pl.slug = \'' . pSQL($slug) . '\''
        );

        return $row ?: null;
    }

    /** Cerca lo slug in tutte le lingue (per link vecchi o lingua sbagliata). */
    public static function findIdBySlugAnyLang($slug, $idShop)
    {
        return (int) Db::getInstance()->getValue(
            'SELECT p.id_seopilot_post FROM `' . self::table() . '` p
             INNER JOIN `' . self::table(true) . '` pl ON pl.id_seopilot_post = p.id_seopilot_post
             WHERE p.id_shop = ' . (int) $idShop . ' AND p.active = 1 AND pl.slug = \'' . pSQL($slug) . '\''
        );
    }

    public static function getLangRows($idPost)
    {
        $rows = Db::getInstance()->executeS('SELECT * FROM `' . self::table(true) . '` WHERE id_seopilot_post = ' . (int) $idPost) ?: [];
        $out = [];
        foreach ($rows as $r) {
            $out[(int) $r['id_lang']] = $r;
        }

        return $out;
    }

    public static function getIdByExternal($externalId, $idShop)
    {
        return (int) Db::getInstance()->getValue(
            'SELECT id_seopilot_post FROM `' . self::table() . '` WHERE id_shop = ' . (int) $idShop . ' AND external_id = \'' . pSQL($externalId) . '\''
        );
    }

    /**
     * Crea o aggiorna un articolo.
     *
     * @param array $data ['external_id','source','image','active','date_publish']
     * @param array $langs [id_lang => ['title','slug','excerpt','content','meta_title','meta_description','keyword','image_alt']]
     *
     * @return array [id, created(bool)]
     */
    public static function upsert($idShop, array $data, array $langs)
    {
        $db = Db::getInstance();
        $now = date('Y-m-d H:i:s');
        $id = !empty($data['external_id']) ? self::getIdByExternal($data['external_id'], $idShop) : 0;
        $row = [
            'id_shop' => (int) $idShop,
            'external_id' => pSQL(isset($data['external_id']) ? $data['external_id'] : ''),
            'source' => pSQL(isset($data['source']) ? $data['source'] : 'platform'),
            'image' => pSQL(isset($data['image']) ? $data['image'] : ''),
            'active' => isset($data['active']) ? (int) (bool) $data['active'] : 1,
            'date_publish' => pSQL(!empty($data['date_publish']) ? $data['date_publish'] : $now),
            'date_upd' => $now,
        ];
        $created = false;
        if ($id) {
            if ($row['image'] === '') {
                unset($row['image']); // non cancellare l'immagine esistente
            }
            if (empty($data['date_publish'])) {
                unset($row['date_publish']); // aggiornamento: resta la data originale
            }
            $db->update('seopilot_post', $row, 'id_seopilot_post = ' . (int) $id);
        } else {
            $row['date_add'] = $now;
            $db->insert('seopilot_post', $row);
            $id = (int) $db->Insert_ID();
            $created = true;
        }
        foreach ($langs as $idLang => $l) {
            $slug = self::uniqueSlug(Tools::str2url($l['slug'] !== '' ? $l['slug'] : $l['title']), (int) $idLang, $idShop, $id);
            $lrow = [
                'id_seopilot_post' => (int) $id,
                'id_lang' => (int) $idLang,
                'title' => pSQL($l['title']),
                'slug' => pSQL($slug),
                'excerpt' => pSQL(isset($l['excerpt']) ? $l['excerpt'] : ''),
                'content' => pSQL(isset($l['content']) ? $l['content'] : '', true),
                'meta_title' => pSQL(isset($l['meta_title']) ? $l['meta_title'] : ''),
                'meta_description' => pSQL(isset($l['meta_description']) ? $l['meta_description'] : ''),
                'keyword' => pSQL(isset($l['keyword']) ? $l['keyword'] : ''),
                'image_alt' => pSQL(isset($l['image_alt']) ? $l['image_alt'] : ''),
            ];
            $db->insert('seopilot_post_lang', $lrow, false, true, Db::REPLACE);
        }

        return [$id, $created];
    }

    public static function uniqueSlug($slug, $idLang, $idShop, $exceptId)
    {
        $slug = $slug !== '' ? $slug : 'articolo';
        $base = $slug;
        $i = 2;
        while ((int) Db::getInstance()->getValue(
            'SELECT pl.id_seopilot_post FROM `' . self::table(true) . '` pl
             INNER JOIN `' . self::table() . '` p ON p.id_seopilot_post = pl.id_seopilot_post AND p.id_shop = ' . (int) $idShop . '
             WHERE pl.id_lang = ' . (int) $idLang . ' AND pl.slug = \'' . pSQL($slug) . '\' AND pl.id_seopilot_post <> ' . (int) $exceptId
        )) {
            $slug = $base . '-' . $i++;
        }

        return $slug;
    }

    public static function delete($idPost)
    {
        $db = Db::getInstance();

        return $db->delete('seopilot_post_lang', 'id_seopilot_post = ' . (int) $idPost)
            && $db->delete('seopilot_post', 'id_seopilot_post = ' . (int) $idPost);
    }
}
