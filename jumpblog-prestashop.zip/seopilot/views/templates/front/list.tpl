{extends file='page.tpl'}

{block name='page_title'}{$sp_title}{/block}

{block name='page_content'}
  <section class="seopilot-blog">
    {if $sp_desc}<p class="seopilot-intro">{$sp_desc}</p>{/if}
    {if $sp_posts}
      <div class="seopilot-grid">
        {foreach from=$sp_posts item=p}
          <article class="seopilot-card">
            <a href="{$p.url}" class="seopilot-card-link">
              {if $p.image_url}
                <img src="{$p.image_url}" alt="{$p.image_alt|default:$p.title}" loading="lazy" width="600" height="338">
              {/if}
              <div class="seopilot-card-body">
                <h2 class="seopilot-card-title">{$p.title}</h2>
                <time datetime="{$p.date_iso}">{$p.date_publish|date_format:'%d/%m/%Y'}</time>
                {if $p.excerpt}<p>{$p.excerpt}</p>{/if}
              </div>
            </a>
          </article>
        {/foreach}
      </div>
      {if $sp_pages > 1}
        <nav class="seopilot-pagination">
          {if $sp_prev}<a rel="prev" href="{$sp_prev}">&laquo;</a>{/if}
          <span>{$sp_page} / {$sp_pages}</span>
          {if $sp_next}<a rel="next" href="{$sp_next}">&raquo;</a>{/if}
        </nav>
      {/if}
    {else}
      <p>{l s='Nessun articolo pubblicato.' mod='seopilot'}</p>
    {/if}
  </section>
  <script type="application/ld+json">{$sp_jsonld nofilter}</script>
{/block}
