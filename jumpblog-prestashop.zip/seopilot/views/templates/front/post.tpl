{extends file='page.tpl'}

{block name='page_title'}{$sp_post.title}{/block}

{block name='page_content'}
  <article class="seopilot-post">
    <p class="seopilot-meta">
      <time datetime="{$sp_post.date_publish|date_format:'%Y-%m-%d'}">{$sp_post.date_publish|date_format:'%d/%m/%Y'}</time>
    </p>
    {if $sp_image}
      <img class="seopilot-cover" src="{$sp_image}" alt="{$sp_post.image_alt|default:$sp_post.title}" width="1200" height="675">
    {/if}
    <div class="seopilot-content">
      {$sp_post.content nofilter}
    </div>
  </article>

  {if $sp_related}
    <aside class="seopilot-related">
      <h2>{l s='Leggi anche' mod='seopilot'}</h2>
      <ul>
        {foreach from=$sp_related item=r name=rel}
          {if $smarty.foreach.rel.iteration <= 3}
            <li><a href="{$r.url}">{$r.title}</a></li>
          {/if}
        {/foreach}
      </ul>
      <p><a href="{$sp_blog_url}">{l s='Tutti gli articoli' mod='seopilot'}</a></p>
    </aside>
  {/if}
  <script type="application/ld+json">{$sp_jsonld nofilter}</script>
{/block}
